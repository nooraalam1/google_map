# git clone
# npm i
# delete the .git file
