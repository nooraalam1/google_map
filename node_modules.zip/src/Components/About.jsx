import React from 'react';

const About = () => {
    return (
        <div>
            Eita about section.. nije nije add kor
        </div>
    );
};

export default About;