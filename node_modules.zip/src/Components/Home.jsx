import React from 'react';

const Home = () => {
    return (
        <div>
            eita home page.. Ekhane kisu image add korbi + details add kor
        </div>
    );
};

export default Home;